$(".humburguer").click(function(){
    $(".humburguer").toggleClass("open");
    $("#nav-pc").toggleClass("menu");
});